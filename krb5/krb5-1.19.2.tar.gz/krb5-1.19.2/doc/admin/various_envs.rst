Various links
=============

Whitepapers
-----------

#. https://kerberos.org/software/whitepapers.html


Tutorials
---------

#. Fulvio Ricciardi  <https://www.kerberos.org/software/tutorial.html>_


Troubleshooting
---------------

#. https://wiki.ncsa.illinois.edu/display/ITS/Windows+Kerberos+Troubleshooting

#. https://www.shrubbery.net/solaris9ab/SUNWaadm/SYSADV6/p27.html

#. https://docs.oracle.com/cd/E19253-01/816-4557/trouble-1/index.html

#. https://docs.microsoft.com/en-us/previous-versions/tn-archive/bb463167(v=technet.10)#EBAA

#. https://bugs.launchpad.net/ubuntu/+source/libpam-heimdal/+bug/86528
