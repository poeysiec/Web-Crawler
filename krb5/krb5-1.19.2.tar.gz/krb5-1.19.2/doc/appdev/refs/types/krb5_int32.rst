.. highlight:: c

.. _krb5-int32-struct:

krb5_int32
==========

..
.. c:type:: krb5_int32
..

krb5_int32 is a signed 32-bit integer type
